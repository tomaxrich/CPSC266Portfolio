$("#hide").on({
    load: function(){
        $("#hide").hide();
    }
}
,{
    click: function(){
        $("#hide").show();
    }
});